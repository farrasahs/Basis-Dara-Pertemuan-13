import mysql.connector as connector

connection = connector.connect(
    user="root",
    password="Akufarrasah99_",
    host="localhost"
)

cursor = connection.cursor()

# Buat database jika belum ada
cursor.execute("CREATE DATABASE IF NOT EXISTS little_lemon")

# Pilih database
cursor.execute("USE little_lemon")

# Membuat tabel
create_menuitem_table = """
CREATE TABLE IF NOT EXISTS MenuItems(
    ItemID INT AUTO_INCREMENT,
    Name VARCHAR(100),
    Type VARCHAR(100),
    Price INT,
    PRIMARY KEY (ItemID)
);
"""

cursor.execute(create_menuitem_table)

print("Database and table created successfully.")

connection.commit()
cursor.close()
connection.close()
