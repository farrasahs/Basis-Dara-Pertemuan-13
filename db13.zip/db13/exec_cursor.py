import mysql.connector as connector

connection = connector.connect(
    user="root",
    password="Akufarrasah99_",
    host="localhost"
)

cursor = connection.cursor()

cursor.execute("USE little_lemon")

# =========================
# CREATE TABLE Menus
# =========================
create_menu_table = """
CREATE TABLE IF NOT EXISTS Menus (
    MenuID INT,
    ItemID INT,
    Cuisine VARCHAR(100),
    PRIMARY KEY (MenuID, ItemID)
);
"""
cursor.execute(create_menu_table)
print("Table Menus created successfully!")


# =========================
# CREATE TABLE Bookings
# =========================
create_bookings_table = """
CREATE TABLE IF NOT EXISTS Bookings (
    BookingID INT PRIMARY KEY,
    TableNo INT,
    GuestFirstName VARCHAR(100),
    GuestLastName VARCHAR(100),
    BookingSlot TIME,
    EmployeeID INT
);
"""
cursor.execute(create_bookings_table)
print("Table Bookings created successfully!")


# =========================
# CREATE TABLE Orders
# =========================
create_orders_table = """
CREATE TABLE IF NOT EXISTS Orders (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    Quantity INT,
    TotalCost DECIMAL(10,2)
);
"""
cursor.execute(create_orders_table)
print("Table Orders created successfully!")


# =========================
# SHOW TABLES
# =========================
cursor.execute("SHOW TABLES")
for table in cursor:
    print(table)
