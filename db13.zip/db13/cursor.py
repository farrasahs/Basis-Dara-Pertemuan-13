import mysql.connector as connector

connection = connector.connect(
    user="root",
    password="Akufarrasah99_",
    host="localhost"
)

cursor = connection.cursor()   

cursor.execute("USE little_lemon")

cursor.execute("SELECT name, type FROM menuitems")
for name, type in cursor:
    print("Name: ", name)
    print("Type: ", type)
