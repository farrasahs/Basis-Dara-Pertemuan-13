import mysql.connector as connector

connection = connector.connect(
    user="root",
    password="Akufarrasah99_",   
    port=3306,
    host="localhost",
    database="testdb"
)


