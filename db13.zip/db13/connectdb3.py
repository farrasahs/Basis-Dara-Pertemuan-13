import mysql.connector as connector

try:
    connection = connector.connect(user="not root!", password="")
except:
    print("here was an error connecting tp the database")