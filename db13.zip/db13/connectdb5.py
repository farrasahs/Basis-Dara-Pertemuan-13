import mysql.connector as connector

try:
    connection = connector.connect(
        user    = "root",
        password = "password",
        database = "testdb"
    )

except connector.Error as er:
    print("Error code:", er.errno)
    print("Error message:", er.msg)
